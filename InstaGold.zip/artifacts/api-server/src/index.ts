import http from "http";
import { Server as SocketIOServer } from "socket.io";
import app from "./app.js";
import { logger } from "./lib/logger.js";
import { setSocketIO } from "./lib/botManager.js";
import { setTelegramSocketIO } from "./lib/telegramManager.js";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

const server = http.createServer(app);

const io = new SocketIOServer(server, {
  path: "/api/socket.io",
  cors: {
    origin: "*",
    methods: ["GET", "POST"],
  },
});

setSocketIO(io);
setTelegramSocketIO(io);

io.on("connection", (socket) => {
  logger.info({ socketId: socket.id }, "WebSocket client connected");
  socket.on("disconnect", () => {
    logger.info({ socketId: socket.id }, "WebSocket client disconnected");
  });
});

server.listen(port, () => {
  logger.info({ port }, "Server listening");
});
