import { spawn, ChildProcess } from "child_process";
import path from "path";
import { fileURLToPath } from "url";
import fs from "fs";
import type { Server as SocketIOServer } from "socket.io";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const BOTS_DIR = path.resolve(__dirname, "../bots");

export type BotId = "julhas" | "blk";

interface SlotProcess {
  process: ChildProcess;
  startedAt: string;
  pid: number;
}

interface BotState {
  slots: Map<number, SlotProcess>;
  outputBuffer: string[];
}

const MAX_LINES = 500;

const SHARED_FILES = [
  "main.py",
  "xC4.py",
  "xHeaders.py",
  "xKEys.py",
  "emotes.json",
  "room_join_pb2.py",
  "Pb2",
  "full_squad_1766157883.json",
];

const bots: Record<BotId, BotState> = {
  julhas: { slots: new Map(), outputBuffer: [] },
  blk: { slots: new Map(), outputBuffer: [] },
};

let io: SocketIOServer | null = null;

export function setSocketIO(socketIO: SocketIOServer) {
  io = socketIO;
}

function getBotDir(botId: BotId): string {
  return path.join(BOTS_DIR, botId);
}

function getSlotDir(botId: BotId, slotId: number): string {
  return path.join(BOTS_DIR, botId, "slots", String(slotId));
}

function prepareSlotDir(botId: BotId, slotId: number, uid: string, password: string): string {
  const botDir = getBotDir(botId);
  const slotDir = getSlotDir(botId, slotId);

  fs.mkdirSync(slotDir, { recursive: true });

  fs.writeFileSync(path.join(slotDir, "bot.txt"), `uid=${uid}\npassword=${password}`, "utf8");

  for (const file of SHARED_FILES) {
    const src = path.join(botDir, file);
    const dst = path.join(slotDir, file);
    if (!fs.existsSync(src)) continue;
    try { fs.rmSync(dst, { recursive: true, force: true }); } catch { }
    try { fs.symlinkSync(src, dst); } catch { }
  }

  const tokenSrc = path.join(botDir, "token.json");
  const tokenDst = path.join(slotDir, "token.json");
  if (fs.existsSync(tokenSrc) && !fs.existsSync(tokenDst)) {
    try { fs.copyFileSync(tokenSrc, tokenDst); } catch { }
  }

  return slotDir;
}

function addOutput(botId: BotId, text: string) {
  const timestamp = new Date().toLocaleTimeString("en-US", { hour12: false });
  const line = `[${timestamp}] ${text}`;
  const state = bots[botId];
  state.outputBuffer.push(line);
  if (state.outputBuffer.length > MAX_LINES) {
    state.outputBuffer = state.outputBuffer.slice(-MAX_LINES);
  }
  if (io) {
    io.emit(`bot:output:${botId}`, { line });
  }
}

function broadcastStatus(botId: BotId) {
  if (io) {
    const status = getStatus(botId);
    io.emit(`bot:status:${botId}`, status);
    io.emit(`bot:slots:${botId}`, status.slots);
  }
}

export function getSlotStatus(botId: BotId, slotId: number) {
  const slot = bots[botId].slots.get(slotId);
  return {
    slotId,
    isRunning: !!slot,
    pid: slot?.pid ?? null,
    startedAt: slot?.startedAt ?? null,
  };
}

export function getSlotsStatus(botId: BotId): Record<string, { slotId: number; isRunning: boolean; pid: number | null; startedAt: string | null }> {
  const result: Record<string, { slotId: number; isRunning: boolean; pid: number | null; startedAt: string | null }> = {};
  for (let i = 1; i <= 5; i++) {
    result[String(i)] = getSlotStatus(botId, i);
  }
  return result;
}

export function getStatus(botId: BotId) {
  const state = bots[botId];
  const running = state.slots.size > 0;
  const firstSlot = Array.from(state.slots.values())[0];
  return {
    botId,
    isRunning: running,
    uptime: running ? `${state.slots.size} slot(s) running` : "Stopped",
    startedAt: firstSlot?.startedAt ?? null,
    pid: firstSlot?.pid ?? null,
    slotsRunning: state.slots.size,
    slots: getSlotsStatus(botId),
  };
}

export function getAllStatus() {
  return {
    julhas: getStatus("julhas"),
    blk: getStatus("blk"),
  };
}

export function getOutput(botId: BotId) {
  return {
    botId,
    output: bots[botId].outputBuffer,
  };
}

export function startSlot(
  botId: BotId,
  slotId: number,
  uid: string,
  password: string
): { success: boolean; message: string } {
  const state = bots[botId];

  if (state.slots.has(slotId)) {
    return { success: false, message: `Slot ${slotId} is already running` };
  }

  try {
    addOutput(botId, `[Slot ${slotId}] Starting... (UID: ${uid})`);

    const slotDir = prepareSlotDir(botId, slotId, uid, password);
    const pythonBin =
      process.env["PYTHON_BIN"] ?? "/home/runner/workspace/.pythonlibs/bin/python3";

    const proc = spawn(pythonBin, ["-u", "main.py"], {
      cwd: slotDir,
      stdio: ["pipe", "pipe", "pipe"],
      env: {
        ...process.env,
        PYTHONUNBUFFERED: "1",
        PYTHONPATH: slotDir,
        PATH: `/home/runner/workspace/.pythonlibs/bin:${process.env["PATH"] ?? ""}`,
      },
    });

    const slotProc: SlotProcess = {
      process: proc,
      startedAt: new Date().toISOString(),
      pid: proc.pid ?? 0,
    };

    state.slots.set(slotId, slotProc);

    proc.stdout?.on("data", (data: Buffer) => {
      const text = data.toString().trim();
      if (text) addOutput(botId, `[S${slotId}] ${text}`);
    });

    proc.stderr?.on("data", (data: Buffer) => {
      const text = data.toString().trim();
      if (text) addOutput(botId, `[S${slotId}] ERROR: ${text}`);
    });

    proc.on("close", (code: number | null) => {
      state.slots.delete(slotId);
      addOutput(
        botId,
        code === 0
          ? `[S${slotId}] Stopped.`
          : `[S${slotId}] Exited with code: ${code}`
      );
      broadcastStatus(botId);
    });

    proc.on("error", (err: Error) => {
      state.slots.delete(slotId);
      addOutput(botId, `[S${slotId}] Error: ${err.message}`);
      broadcastStatus(botId);
    });

    addOutput(botId, `[Slot ${slotId}] Started (PID: ${proc.pid})`);
    broadcastStatus(botId);
    return { success: true, message: `Slot ${slotId} started` };
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    state.slots.delete(slotId);
    addOutput(botId, `[S${slotId}] Failed to start: ${msg}`);
    broadcastStatus(botId);
    return { success: false, message: msg };
  }
}

export function stopSlot(
  botId: BotId,
  slotId: number
): { success: boolean; message: string } {
  const state = bots[botId];
  const slot = state.slots.get(slotId);
  if (!slot) {
    return { success: false, message: `Slot ${slotId} is not running` };
  }
  addOutput(botId, `[S${slotId}] Stopping...`);
  slot.process.kill("SIGINT");
  setTimeout(() => {
    if (state.slots.has(slotId)) {
      slot.process.kill("SIGKILL");
      state.slots.delete(slotId);
      broadcastStatus(botId);
    }
  }, 5000);
  return { success: true, message: `Slot ${slotId} stopping...` };
}

export function forceStopSlot(
  botId: BotId,
  slotId: number
): { success: boolean; message: string } {
  const state = bots[botId];
  const slot = state.slots.get(slotId);
  if (!slot) {
    return { success: false, message: `Slot ${slotId} is not running` };
  }
  addOutput(botId, `[S${slotId}] Force stopping...`);
  slot.process.kill("SIGKILL");
  state.slots.delete(slotId);
  broadcastStatus(botId);
  return { success: true, message: `Slot ${slotId} force stopped` };
}

export function startBot(
  botId: BotId,
  accounts: Array<{ id: number; uid: string; password: string; active: boolean }>
): { success: boolean; message: string; started: number } {
  const eligible = accounts.filter((a) => a.active && a.uid && a.password);
  if (eligible.length === 0) {
    return {
      success: false,
      message: "No enabled accounts with credentials found. Enable at least one account slot.",
      started: 0,
    };
  }
  let started = 0;
  for (const acc of eligible) {
    const result = startSlot(botId, acc.id, acc.uid, acc.password);
    if (result.success) started++;
  }
  return { success: started > 0, message: `Started ${started} slot(s)`, started };
}

export function stopBot(botId: BotId): { success: boolean; message: string } {
  const state = bots[botId];
  if (state.slots.size === 0) {
    return { success: false, message: "No slots are running" };
  }
  addOutput(botId, "Stopping all slots...");
  for (const [slotId] of state.slots) {
    stopSlot(botId, slotId);
  }
  return { success: true, message: "All slots stopping..." };
}

export function forceStopBot(botId: BotId): { success: boolean; message: string } {
  const state = bots[botId];
  if (state.slots.size === 0) {
    return { success: false, message: "No slots are running" };
  }
  addOutput(botId, "Force stopping all slots...");
  const slotIds = Array.from(state.slots.keys());
  for (const slotId of slotIds) {
    forceStopSlot(botId, slotId);
  }
  return { success: true, message: "All slots force stopped" };
}

export function restartBot(
  botId: BotId,
  accounts: Array<{ id: number; uid: string; password: string; active: boolean }>
): { success: boolean; message: string } {
  const wasRunning = bots[botId].slots.size > 0;
  if (wasRunning) {
    addOutput(botId, "Restarting all slots...");
    stopBot(botId);
    setTimeout(() => startBot(botId, accounts), 3000);
    return { success: true, message: "Restarting..." };
  }
  const result = startBot(botId, accounts);
  return { success: result.success, message: result.message };
}

export function clearOutput(botId: BotId): { success: boolean; message: string } {
  bots[botId].outputBuffer = [];
  if (io) {
    io.emit(`bot:cleared:${botId}`, {});
  }
  addOutput(botId, "Console cleared.");
  return { success: true, message: "Console cleared" };
}
