import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const BOTS_DIR = path.resolve(__dirname, "../bots");

export type BotId = "julhas" | "blk";

export interface BotAccount {
  id: number;
  label: string;
  uid: string;
  password: string;
  active: boolean;
}

const DEFAULT_ACCOUNTS = (): BotAccount[] =>
  Array.from({ length: 5 }, (_, i) => ({
    id: i + 1,
    label: `Account ${i + 1}`,
    uid: "",
    password: "",
    active: false,
  }));

function accountsPath(botId: BotId): string {
  return path.join(BOTS_DIR, botId, "accounts.json");
}

function botTxtPath(botId: BotId): string {
  return path.join(BOTS_DIR, botId, "bot.txt");
}

function readCurrentBotTxt(botId: BotId): { uid: string; password: string } | null {
  try {
    const content = fs.readFileSync(botTxtPath(botId), "utf8");
    const uid = (content.match(/uid=(.+)/) || [])[1]?.trim() ?? "";
    const password = (content.match(/password=(.+)/) || [])[1]?.trim() ?? "";
    return uid ? { uid, password } : null;
  } catch {
    return null;
  }
}

export function loadAccounts(botId: BotId): BotAccount[] {
  try {
    const raw = fs.readFileSync(accountsPath(botId), "utf8");
    const data = JSON.parse(raw) as BotAccount[];
    if (Array.isArray(data) && data.length === 5) return data;
  } catch {
    // first run — seed from bot.txt
    const current = readCurrentBotTxt(botId);
    if (current) {
      const accounts = DEFAULT_ACCOUNTS();
      accounts[0].uid = current.uid;
      accounts[0].password = current.password;
      accounts[0].label = "Account 1";
      accounts[0].active = true;
      return accounts;
    }
  }
  return DEFAULT_ACCOUNTS();
}

export function saveAccounts(botId: BotId, accounts: BotAccount[]): void {
  fs.writeFileSync(accountsPath(botId), JSON.stringify(accounts, null, 2), "utf8");
}

export function getActiveIds(accounts: BotAccount[]): number[] {
  return accounts.filter((a) => a.active).map((a) => a.id);
}

/** Keep for backward compat — returns first active id or null */
export function getActiveId(accounts: BotAccount[]): number | null {
  return accounts.find((a) => a.active)?.id ?? null;
}

/**
 * Toggle the active (enabled) state of an account.
 * Multiple accounts can be active at the same time.
 */
export function toggleAccount(botId: BotId, accountId: number): { success: boolean; message: string; active: boolean } {
  const accounts = loadAccounts(botId);
  const target = accounts.find((a) => a.id === accountId);
  if (!target) return { success: false, message: `Account ${accountId} not found`, active: false };

  if (!target.active && (!target.uid || !target.password)) {
    return { success: false, message: "Cannot enable: UID or password is empty", active: false };
  }

  target.active = !target.active;
  saveAccounts(botId, accounts);

  return {
    success: true,
    message: target.active
      ? `Account ${accountId} enabled`
      : `Account ${accountId} disabled`,
    active: target.active,
  };
}

/** Legacy single-activate kept for any callers that still use it */
export function activateAccount(botId: BotId, accountId: number): { success: boolean; message: string } {
  return toggleAccount(botId, accountId);
}
