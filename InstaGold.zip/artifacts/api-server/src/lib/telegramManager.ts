import { spawn, ChildProcess } from "child_process";
import path from "path";
import { fileURLToPath } from "url";
import fs from "fs";
import type { Server as SocketIOServer } from "socket.io";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const BOT_DIR = path.resolve(__dirname, "../bots/telegram");
const MAINTENANCE_FILE = path.join(BOT_DIR, "maintenance2.json");

interface TelegramState {
  process: ChildProcess | null;
  isRunning: boolean;
  startedAt: string | null;
  pid: number | null;
  outputBuffer: string[];
}

const MAX_LINES = 500;

const state: TelegramState = {
  process: null,
  isRunning: false,
  startedAt: null,
  pid: null,
  outputBuffer: [],
};

let io: SocketIOServer | null = null;

export function setTelegramSocketIO(socketIO: SocketIOServer) {
  io = socketIO;
}

function addOutput(text: string) {
  const timestamp = new Date().toLocaleTimeString("en-US", { hour12: false });
  const line = `[${timestamp}] ${text}`;
  state.outputBuffer.push(line);
  if (state.outputBuffer.length > MAX_LINES) {
    state.outputBuffer = state.outputBuffer.slice(-MAX_LINES);
  }
  if (io) io.emit("telegram:output", { line });
}

function broadcastStatus() {
  if (io) io.emit("telegram:status", getTelegramStatus());
}

// ── Maintenance mode ──────────────────────────────────────────────────────────

export function getMaintenanceMode(): boolean {
  try {
    if (!fs.existsSync(MAINTENANCE_FILE)) return false;
    const data = JSON.parse(fs.readFileSync(MAINTENANCE_FILE, "utf8"));
    return Boolean(data.maintenance_mode);
  } catch {
    return false;
  }
}

export function setMaintenanceMode(enabled: boolean): { success: boolean; message: string } {
  try {
    fs.writeFileSync(
      MAINTENANCE_FILE,
      JSON.stringify({ maintenance_mode: enabled }, null, 2),
      "utf8"
    );
    addOutput(enabled ? "🔧 وضع الصيانة مُفعَّل" : "✅ وضع الصيانة أُلغي");
    broadcastStatus();
    return {
      success: true,
      message: enabled ? "Maintenance mode enabled" : "Maintenance mode disabled",
    };
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    return { success: false, message: msg };
  }
}

// ── Status ────────────────────────────────────────────────────────────────────

export function getTelegramStatus() {
  return {
    isRunning: state.isRunning,
    pid: state.pid,
    startedAt: state.startedAt,
    uptime: state.isRunning ? "Running" : "Stopped",
    maintenanceMode: getMaintenanceMode(),
  };
}

export function getTelegramOutput() {
  return { output: state.outputBuffer };
}

// ── Process control ───────────────────────────────────────────────────────────

export function startTelegramBot(): { success: boolean; message: string } {
  if (state.isRunning) {
    return { success: false, message: "Telegram bot is already running" };
  }

  try {
    addOutput("Starting Telegram bot...");

    const pythonBin =
      process.env["PYTHON_BIN"] ?? "/home/runner/workspace/.pythonlibs/bin/python3";

    const proc = spawn(pythonBin, ["-u", "main.py"], {
      cwd: BOT_DIR,
      stdio: ["pipe", "pipe", "pipe"],
      env: {
        ...process.env,
        PYTHONUNBUFFERED: "1",
        PYTHONPATH: BOT_DIR,
        PATH: `/home/runner/workspace/.pythonlibs/bin:${process.env["PATH"] ?? ""}`,
      },
    });

    state.process = proc;
    state.isRunning = true;
    state.startedAt = new Date().toISOString();
    state.pid = proc.pid ?? null;

    proc.stdout?.on("data", (data: Buffer) => {
      const text = data.toString().trim();
      if (text) addOutput(text);
    });

    proc.stderr?.on("data", (data: Buffer) => {
      const text = data.toString().trim();
      if (text) addOutput(`ERROR: ${text}`);
    });

    proc.on("close", (code: number | null) => {
      state.isRunning = false;
      state.process = null;
      state.startedAt = null;
      state.pid = null;
      addOutput(code === 0 ? "Bot stopped." : `Bot exited with code: ${code}`);
      broadcastStatus();
    });

    proc.on("error", (err: Error) => {
      state.isRunning = false;
      state.process = null;
      state.startedAt = null;
      state.pid = null;
      addOutput(`Error: ${err.message}`);
      broadcastStatus();
    });

    addOutput(`Telegram bot started (PID: ${proc.pid})`);
    broadcastStatus();
    return { success: true, message: "Telegram bot started" };
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    state.isRunning = false;
    addOutput(`Failed: ${msg}`);
    broadcastStatus();
    return { success: false, message: msg };
  }
}

export function stopTelegramBot(): { success: boolean; message: string } {
  if (!state.isRunning || !state.process) {
    return { success: false, message: "Bot is not running" };
  }
  addOutput("Stopping Telegram bot...");
  state.process.kill("SIGINT");
  setTimeout(() => {
    if (state.isRunning && state.process) {
      state.process.kill("SIGKILL");
    }
  }, 5000);
  return { success: true, message: "Bot stopping..." };
}

export function forceStopTelegramBot(): { success: boolean; message: string } {
  if (!state.isRunning || !state.process) {
    return { success: false, message: "Bot is not running" };
  }
  addOutput("Force stopping Telegram bot...");
  state.process.kill("SIGKILL");
  state.isRunning = false;
  state.process = null;
  state.startedAt = null;
  state.pid = null;
  broadcastStatus();
  return { success: true, message: "Bot force stopped" };
}

export function restartTelegramBot(): { success: boolean; message: string } {
  if (state.isRunning) {
    addOutput("Restarting Telegram bot...");
    stopTelegramBot();
    setTimeout(() => startTelegramBot(), 3000);
    return { success: true, message: "Bot restarting..." };
  }
  return startTelegramBot();
}

export function clearTelegramOutput(): { success: boolean; message: string } {
  state.outputBuffer = [];
  if (io) io.emit("telegram:cleared", {});
  addOutput("Console cleared.");
  return { success: true, message: "Console cleared" };
}
