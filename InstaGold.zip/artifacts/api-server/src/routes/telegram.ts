import { Router } from "express";
import {
  getTelegramStatus,
  getTelegramOutput,
  startTelegramBot,
  stopTelegramBot,
  forceStopTelegramBot,
  restartTelegramBot,
  clearTelegramOutput,
  setMaintenanceMode,
  getMaintenanceMode,
} from "../lib/telegramManager.js";

const router = Router();

router.get("/status", (_req, res) => {
  res.json(getTelegramStatus());
});

router.get("/output", (_req, res) => {
  res.json(getTelegramOutput());
});

router.post("/start", (_req, res) => {
  const result = startTelegramBot();
  res.json(result);
});

router.post("/stop", (_req, res) => {
  const result = stopTelegramBot();
  res.json(result);
});

router.post("/restart", (_req, res) => {
  const result = restartTelegramBot();
  res.json(result);
});

router.post("/force-stop", (_req, res) => {
  const result = forceStopTelegramBot();
  res.json(result);
});

router.post("/clear-console", (_req, res) => {
  const result = clearTelegramOutput();
  res.json(result);
});

router.get("/maintenance", (_req, res) => {
  res.json({ maintenanceMode: getMaintenanceMode() });
});

router.post("/maintenance/on", (_req, res) => {
  const result = setMaintenanceMode(true);
  res.json(result);
});

router.post("/maintenance/off", (_req, res) => {
  const result = setMaintenanceMode(false);
  res.json(result);
});

export default router;
