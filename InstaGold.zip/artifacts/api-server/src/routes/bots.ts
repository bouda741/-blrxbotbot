import { Router } from "express";
import {
  getStatus,
  getAllStatus,
  getOutput,
  startBot,
  stopBot,
  forceStopBot,
  restartBot,
  startSlot,
  stopSlot,
  forceStopSlot,
  getSlotsStatus,
  clearOutput,
  type BotId,
} from "../lib/botManager.js";
import {
  loadAccounts,
  saveAccounts,
  getActiveId,
  toggleAccount,
} from "../lib/accounts.js";

const router = Router();
const VALID_BOTS: BotId[] = ["julhas", "blk"];

function isValidBot(id: string): id is BotId {
  return VALID_BOTS.includes(id as BotId);
}

router.get("/all-status", (_req, res) => {
  res.json(getAllStatus());
});

router.get("/:botId/status", (req, res) => {
  const { botId } = req.params;
  if (!isValidBot(botId)) { res.status(400).json({ error: "Invalid bot ID" }); return; }
  res.json(getStatus(botId));
});

router.get("/:botId/output", (req, res) => {
  const { botId } = req.params;
  if (!isValidBot(botId)) { res.status(400).json({ error: "Invalid bot ID" }); return; }
  res.json(getOutput(botId));
});

// ── Bot-level controls (all slots) ────────────────────────────────────────────

router.post("/:botId/start", (req, res) => {
  const { botId } = req.params;
  if (!isValidBot(botId)) { res.status(400).json({ success: false, message: "Invalid bot ID", botId }); return; }
  const accounts = loadAccounts(botId);
  const result = startBot(botId, accounts);
  res.json({ ...result, botId });
});

router.post("/:botId/stop", (req, res) => {
  const { botId } = req.params;
  if (!isValidBot(botId)) { res.status(400).json({ success: false, message: "Invalid bot ID", botId }); return; }
  const result = stopBot(botId);
  res.json({ ...result, botId });
});

router.post("/:botId/restart", (req, res) => {
  const { botId } = req.params;
  if (!isValidBot(botId)) { res.status(400).json({ success: false, message: "Invalid bot ID", botId }); return; }
  const accounts = loadAccounts(botId);
  const result = restartBot(botId, accounts);
  res.json({ ...result, botId });
});

router.post("/:botId/force-stop", (req, res) => {
  const { botId } = req.params;
  if (!isValidBot(botId)) { res.status(400).json({ success: false, message: "Invalid bot ID", botId }); return; }
  const result = forceStopBot(botId);
  res.json({ ...result, botId });
});

router.post("/:botId/clear-console", (req, res) => {
  const { botId } = req.params;
  if (!isValidBot(botId)) { res.status(400).json({ success: false, message: "Invalid bot ID", botId }); return; }
  const result = clearOutput(botId);
  res.json({ ...result, botId });
});

// ── Slot-level controls ───────────────────────────────────────────────────────

router.get("/:botId/slots/status", (req, res) => {
  const { botId } = req.params;
  if (!isValidBot(botId)) { res.status(400).json({ error: "Invalid bot ID" }); return; }
  res.json({ botId, slots: getSlotsStatus(botId) });
});

router.post("/:botId/slots/:slotId/start", (req, res) => {
  const { botId, slotId } = req.params;
  if (!isValidBot(botId)) { res.status(400).json({ success: false, message: "Invalid bot ID", botId }); return; }
  const id = parseInt(slotId, 10);
  if (isNaN(id) || id < 1 || id > 5) { res.status(400).json({ success: false, message: "slotId must be 1-5", botId }); return; }
  const accounts = loadAccounts(botId);
  const account = accounts.find((a) => a.id === id);
  if (!account) { res.status(404).json({ success: false, message: `Slot ${id} not found`, botId }); return; }
  if (!account.uid || !account.password) {
    res.status(400).json({ success: false, message: `Slot ${id} has no credentials`, botId });
    return;
  }
  const result = startSlot(botId, id, account.uid, account.password);
  res.json({ ...result, botId, slotId: id });
});

router.post("/:botId/slots/:slotId/stop", (req, res) => {
  const { botId, slotId } = req.params;
  if (!isValidBot(botId)) { res.status(400).json({ success: false, message: "Invalid bot ID", botId }); return; }
  const id = parseInt(slotId, 10);
  if (isNaN(id) || id < 1 || id > 5) { res.status(400).json({ success: false, message: "slotId must be 1-5", botId }); return; }
  const result = stopSlot(botId, id);
  res.json({ ...result, botId, slotId: id });
});

router.post("/:botId/slots/:slotId/force-stop", (req, res) => {
  const { botId, slotId } = req.params;
  if (!isValidBot(botId)) { res.status(400).json({ success: false, message: "Invalid bot ID", botId }); return; }
  const id = parseInt(slotId, 10);
  if (isNaN(id) || id < 1 || id > 5) { res.status(400).json({ success: false, message: "slotId must be 1-5", botId }); return; }
  const result = forceStopSlot(botId, id);
  res.json({ ...result, botId, slotId: id });
});

// ── Accounts ─────────────────────────────────────────────────────────────────

router.get("/:botId/accounts", (req, res) => {
  const { botId } = req.params;
  if (!isValidBot(botId)) { res.status(400).json({ error: "Invalid bot ID" }); return; }
  const accounts = loadAccounts(botId);
  res.json({ botId, accounts, activeId: getActiveId(accounts) });
});

router.post("/:botId/accounts", (req, res) => {
  const { botId } = req.params;
  if (!isValidBot(botId)) { res.status(400).json({ success: false, message: "Invalid bot ID", botId }); return; }
  const { accounts } = req.body as { accounts: Parameters<typeof saveAccounts>[1] };
  if (!Array.isArray(accounts) || accounts.length !== 5) {
    res.status(400).json({ success: false, message: "Must provide exactly 5 accounts", botId });
    return;
  }
  saveAccounts(botId, accounts);
  res.json({ success: true, message: "Accounts saved", botId });
});

router.post("/:botId/accounts/activate", (req, res) => {
  const { botId } = req.params;
  if (!isValidBot(botId)) { res.status(400).json({ success: false, message: "Invalid bot ID", botId }); return; }
  const { accountId } = req.body as { accountId: number };
  if (typeof accountId !== "number") {
    res.status(400).json({ success: false, message: "accountId must be a number", botId });
    return;
  }
  const result = toggleAccount(botId, accountId);
  res.json({ ...result, botId });
});

export default router;
