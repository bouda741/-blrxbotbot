import { Router, type IRouter } from "express";
import healthRouter from "./health";
import botsRouter from "./bots";
import telegramRouter from "./telegram";

const router: IRouter = Router();

router.use(healthRouter);
router.use("/bots", botsRouter);
router.use("/telegram", telegramRouter);

export default router;
