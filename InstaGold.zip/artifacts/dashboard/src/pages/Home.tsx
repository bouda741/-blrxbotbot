import { useState, useEffect, useRef } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { io, Socket } from "socket.io-client";
import {
  useGetAllBotsStatus,
  useStartBot,
  useStopBot,
  useRestartBot,
  useForceStopBot,
  useClearBotConsole,
  useGetBotOutput,
  useGetBotAccounts,
  useSaveBotAccounts,
  useActivateBotAccount,
  useGetBotSlotsStatus,
  useStartBotSlot,
  useStopBotSlot,
  useForceStopBotSlot,
  useGetTelegramStatus,
  useGetTelegramOutput,
  useStartTelegramBot,
  useStopTelegramBot,
  useRestartTelegramBot,
  useForceStopTelegramBot,
  useClearTelegramConsole,
  useEnableTelegramMaintenance,
  useDisableTelegramMaintenance,
  getGetAllBotsStatusQueryKey,
  getGetBotOutputQueryKey,
  getGetBotAccountsQueryKey,
  getGetBotSlotsStatusQueryKey,
  getGetTelegramStatusQueryKey,
  getGetTelegramOutputQueryKey,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import {
  Play,
  Square,
  RotateCw,
  Skull,
  Trash2,
  Activity,
  TerminalSquare,
  Server,
  Users,
  Terminal,
  CheckCircle2,
  Eye,
  EyeOff,
  Save,
  Zap,
  Send,
  Wrench,
  ShieldOff,
  ShieldCheck,
} from "lucide-react";

interface BotAccount {
  id: number;
  label: string;
  uid: string;
  password: string;
  active: boolean;
}

// ─── Console line coloring ────────────────────────────────────────────────────

function getLineColor(line: string): string {
  const l = line.toLowerCase();
  if (
    l.includes("error") || l.includes("failed") || l.includes("fail") ||
    l.includes("exception") || l.includes("traceback") || l.includes("خطأ") || l.includes("فشل")
  ) return "text-red-400";
  if (
    l.includes("warn") || l.includes("restarting") || l.includes("reconnect") ||
    l.includes("retry") || l.includes("إعادة")
  ) return "text-yellow-400";
  if (
    l.includes("✅") || l.includes("success") || l.includes("online") ||
    l.includes("connected") || l.includes("ready") || l.includes("started") || l.includes("running")
  ) return "text-green-400";
  if (l.includes("stopping") || l.includes("stopped") || l.includes("kill")) return "text-zinc-400";
  return "text-primary/90";
}

function isErrorLine(line: string) {
  const l = line.toLowerCase();
  return l.includes("error") || l.includes("failed") || l.includes("fail") ||
    l.includes("exception") || l.includes("traceback");
}

// ─── SlotStatus type ──────────────────────────────────────────────────────────

interface SlotStatus {
  slotId: number;
  isRunning: boolean;
  pid: number | null;
  startedAt: string | null;
}

// ─── AccountsPanel ────────────────────────────────────────────────────────────

interface AccountsPanelProps {
  botId: "julhas" | "blk";
  socket: Socket | null;
}

function AccountsPanel({ botId, socket }: AccountsPanelProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [localAccounts, setLocalAccounts] = useState<BotAccount[]>([]);
  const [showPasswords, setShowPasswords] = useState<Record<number, boolean>>({});
  const [dirty, setDirty] = useState(false);
  const [slotStatuses, setSlotStatuses] = useState<Record<string, SlotStatus>>({});

  const { data: accountsData, isLoading } = useGetBotAccounts(botId, {
    query: { queryKey: getGetBotAccountsQueryKey(botId) },
  });

  const { data: slotsData } = useGetBotSlotsStatus(botId, {
    query: { refetchInterval: 3000, queryKey: getGetBotSlotsStatusQueryKey(botId) },
  });

  // Real-time slot updates via socket
  useEffect(() => {
    if (!socket) return;
    const handler = (data: Record<string, SlotStatus>) => setSlotStatuses(data);
    socket.on(`bot:slots:${botId}`, handler);
    return () => { socket.off(`bot:slots:${botId}`, handler); };
  }, [socket, botId]);

  useEffect(() => {
    if (slotsData?.slots) setSlotStatuses(slotsData.slots as Record<string, SlotStatus>);
  }, [slotsData]);

  const saveMut = useSaveBotAccounts({
    mutation: {
      onSuccess: () => {
        toast({ title: "Saved", description: "Accounts saved successfully" });
        setDirty(false);
        queryClient.invalidateQueries({ queryKey: getGetBotAccountsQueryKey(botId) });
      },
      onError: (err: any) => {
        toast({ title: "Error", description: err.message || "Failed to save", variant: "destructive" });
      },
    },
  });

  const toggleMut = useActivateBotAccount({
    mutation: {
      onSuccess: (data) => {
        toast({ title: data.success ? "Done" : "Error", description: data.message, variant: data.success ? "default" : "destructive" });
        queryClient.invalidateQueries({ queryKey: getGetBotAccountsQueryKey(botId) });
      },
    },
  });

  const slotStartMut = useStartBotSlot({
    mutation: {
      onSuccess: (data) => {
        toast({ title: data.success ? "Slot Starting" : "Error", description: data.message, variant: data.success ? "default" : "destructive" });
        queryClient.invalidateQueries({ queryKey: getGetBotSlotsStatusQueryKey(botId) });
        queryClient.invalidateQueries({ queryKey: getGetAllBotsStatusQueryKey() });
      },
    },
  });

  const slotStopMut = useStopBotSlot({
    mutation: {
      onSuccess: (data) => {
        toast({ title: "Slot Stopping", description: data.message });
        queryClient.invalidateQueries({ queryKey: getGetBotSlotsStatusQueryKey(botId) });
        queryClient.invalidateQueries({ queryKey: getGetAllBotsStatusQueryKey() });
      },
    },
  });

  const slotForceStopMut = useForceStopBotSlot({
    mutation: {
      onSuccess: (data) => {
        toast({ title: "Force Stopped", description: data.message });
        queryClient.invalidateQueries({ queryKey: getGetBotSlotsStatusQueryKey(botId) });
        queryClient.invalidateQueries({ queryKey: getGetAllBotsStatusQueryKey() });
      },
    },
  });

  useEffect(() => {
    if (accountsData?.accounts) {
      setLocalAccounts(accountsData.accounts.map((a) => ({ ...a })));
      setDirty(false);
    }
  }, [accountsData]);

  function updateField(id: number, field: keyof BotAccount, value: string) {
    setLocalAccounts((prev) => prev.map((a) => (a.id === id ? { ...a, [field]: value } : a)));
    setDirty(true);
  }

  function handleSave() {
    saveMut.mutate({ botId, data: { accounts: localAccounts } } as any);
  }

  function handleToggle(accountId: number) {
    toggleMut.mutate({ botId, data: { accountId } } as any);
  }

  function handleSlotStart(slotId: number) {
    // Save first if dirty
    if (dirty) {
      saveMut.mutate({ botId, data: { accounts: localAccounts } } as any);
    }
    slotStartMut.mutate({ botId, slotId } as any);
  }

  function handleSlotStop(slotId: number) {
    slotStopMut.mutate({ botId, slotId } as any);
  }

  function handleSlotForceStop(slotId: number) {
    slotForceStopMut.mutate({ botId, slotId } as any);
  }

  if (isLoading) {
    return <div className="p-4 text-zinc-500 font-mono text-xs">Loading accounts...</div>;
  }

  const runningCount = Object.values(slotStatuses).filter((s) => s.isRunning).length;

  return (
    <div className="p-4 space-y-3">
      {/* Header */}
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <span className="text-xs font-mono text-zinc-400 uppercase tracking-wider">
            5 Account Slots
          </span>
          {runningCount > 0 && (
            <span className="flex items-center gap-1 px-2 py-0.5 rounded bg-green-500/10 border border-green-500/30 text-green-400 text-[10px] font-mono uppercase">
              <span className="w-1.5 h-1.5 rounded-full bg-green-400 inline-block animate-pulse" />
              {runningCount} running
            </span>
          )}
        </div>
        <Button
          size="sm"
          variant="outline"
          onClick={handleSave}
          disabled={!dirty || saveMut.isPending}
          className="h-7 text-xs font-mono border-primary/30 hover:bg-primary/10 hover:text-primary gap-1.5"
          data-testid={`button-save-accounts-${botId}`}
        >
          <Save className="w-3 h-3" />
          {saveMut.isPending ? "Saving..." : "Save All"}
        </Button>
      </div>

      {localAccounts.map((account) => {
        const isEnabled = accountsData?.accounts.find((a) => a.id === account.id)?.active ?? false;
        const slotStatus = slotStatuses[String(account.id)];
        const isSlotRunning = slotStatus?.isRunning ?? false;
        const hasCredentials = !!account.uid && !!account.password;

        return (
          <div
            key={account.id}
            data-testid={`account-slot-${botId}-${account.id}`}
            className={`rounded-md border p-3 space-y-2 transition-colors ${
              isSlotRunning
                ? "border-green-500/40 bg-green-500/5"
                : isEnabled
                ? "border-primary/50 bg-primary/5"
                : "border-border/40 bg-zinc-900/60"
            }`}
          >
            {/* Row header */}
            <div className="flex items-center gap-2">
              {/* Running status dot */}
              <div className="flex-shrink-0 relative">
                {isSlotRunning ? (
                  <span className="relative flex h-3 w-3">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-500 opacity-60" />
                    <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500" />
                  </span>
                ) : isEnabled ? (
                  <CheckCircle2 className="w-3 h-3 text-primary" />
                ) : (
                  <div className="w-3 h-3 rounded-full border border-zinc-600" />
                )}
              </div>

              <Input
                value={account.label}
                onChange={(e) => updateField(account.id, "label", e.target.value)}
                className="h-6 text-xs font-mono bg-transparent border-0 border-b border-zinc-700 rounded-none px-0 focus-visible:ring-0 text-zinc-300 w-32"
                placeholder={`Account ${account.id}`}
                data-testid={`input-label-${botId}-${account.id}`}
              />

              <div className="ml-auto flex items-center gap-1.5">
                {isSlotRunning && slotStatus?.pid && (
                  <span className="text-[10px] font-mono text-green-400 border border-green-500/30 rounded px-1.5 py-0.5 bg-green-500/10">
                    PID {slotStatus.pid}
                  </span>
                )}
                <span className="text-[10px] font-mono text-zinc-500">
                  #{account.id}
                </span>
              </div>
            </div>

            {/* UID + Password */}
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[10px] font-mono text-zinc-500 uppercase tracking-wider block mb-1">UID</label>
                <Input
                  value={account.uid}
                  onChange={(e) => updateField(account.id, "uid", e.target.value)}
                  className="h-7 text-xs font-mono bg-zinc-950 border-zinc-700 focus-visible:ring-primary/50"
                  placeholder="e.g. 4500312161"
                  data-testid={`input-uid-${botId}-${account.id}`}
                />
              </div>
              <div>
                <label className="text-[10px] font-mono text-zinc-500 uppercase tracking-wider block mb-1">Password</label>
                <div className="relative">
                  <Input
                    type={showPasswords[account.id] ? "text" : "password"}
                    value={account.password}
                    onChange={(e) => updateField(account.id, "password", e.target.value)}
                    className="h-7 text-xs font-mono bg-zinc-950 border-zinc-700 focus-visible:ring-primary/50 pr-8"
                    placeholder="Hash password"
                    data-testid={`input-password-${botId}-${account.id}`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPasswords((p) => ({ ...p, [account.id]: !p[account.id] }))}
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-zinc-300"
                  >
                    {showPasswords[account.id] ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>
            </div>

            {/* Controls row */}
            <div className="flex items-center gap-1.5 pt-1">
              {/* Enable / Disable toggle */}
              <Button
                size="sm"
                variant="outline"
                onClick={() => handleToggle(account.id)}
                disabled={toggleMut.isPending || (!isEnabled && !hasCredentials)}
                className={`h-6 text-[10px] font-mono gap-1 ${
                  isEnabled
                    ? "border-primary/50 bg-primary/10 text-primary hover:bg-primary/20"
                    : "border-zinc-700 text-zinc-400 hover:border-primary/50 hover:text-primary"
                }`}
                data-testid={`button-toggle-${botId}-${account.id}`}
              >
                <CheckCircle2 className="w-2.5 h-2.5" />
                {isEnabled ? "Enabled" : "Enable"}
              </Button>

              <div className="flex-1" />

              {/* Per-slot START */}
              {!isSlotRunning && (
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleSlotStart(account.id)}
                  disabled={!hasCredentials || slotStartMut.isPending}
                  className="h-6 text-[10px] font-mono gap-1 border-green-500/30 text-green-400 hover:bg-green-500/10"
                  data-testid={`button-start-slot-${botId}-${account.id}`}
                  title={!hasCredentials ? "Add UID + Password first" : "Start this slot"}
                >
                  <Play className="w-2.5 h-2.5" />
                  START
                </Button>
              )}

              {/* Per-slot STOP + KILL */}
              {isSlotRunning && (
                <>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleSlotStop(account.id)}
                    disabled={slotStopMut.isPending}
                    className="h-6 text-[10px] font-mono gap-1 border-zinc-600 text-zinc-300 hover:bg-zinc-800"
                    data-testid={`button-stop-slot-${botId}-${account.id}`}
                  >
                    <Square className="w-2.5 h-2.5" />
                    STOP
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleSlotForceStop(account.id)}
                    disabled={slotForceStopMut.isPending}
                    className="h-6 text-[10px] font-mono gap-1 border-destructive/30 text-destructive hover:bg-destructive/10"
                    data-testid={`button-kill-slot-${botId}-${account.id}`}
                  >
                    <Skull className="w-2.5 h-2.5" />
                    KILL
                  </Button>
                </>
              )}
            </div>
          </div>
        );
      })}

      <p className="text-[10px] font-mono text-zinc-600 pt-1 leading-relaxed">
        Enable accounts you want to run, then press <span className="text-zinc-400">START</span> on the bot panel to launch all of them simultaneously.
      </p>
    </div>
  );
}

// ─── BotPanel ─────────────────────────────────────────────────────────────────

interface BotPanelProps {
  botId: "julhas" | "blk";
  title: string;
  socket: Socket | null;
}

function BotPanel({ botId, title, socket }: BotPanelProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const scrollRef = useRef<HTMLDivElement>(null);
  const [consoleLines, setConsoleLines] = useState<string[]>([]);
  const [activeTab, setActiveTab] = useState<"console" | "accounts">("console");
  const [errorCount, setErrorCount] = useState(0);
  const [crashCount, setCrashCount] = useState(0);

  const { data: allStatus } = useGetAllBotsStatus({
    query: { refetchInterval: 3000, queryKey: getGetAllBotsStatusQueryKey() },
  });

  const { data: outputData } = useGetBotOutput(botId, {
    query: { refetchInterval: 2000, queryKey: getGetBotOutputQueryKey(botId) },
  });

  const startMut = useStartBot({
    mutation: {
      onSuccess: (data) => {
        toast({ title: "Bots Starting", description: data.message });
        queryClient.invalidateQueries({ queryKey: getGetAllBotsStatusQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetBotSlotsStatusQueryKey(botId) });
      },
      onError: (err: any) => {
        toast({ title: "Error", description: err.message || "Failed to start", variant: "destructive" });
      },
    },
  });

  const stopMut = useStopBot({
    mutation: {
      onSuccess: (data) => {
        toast({ title: "Stopping", description: data.message });
        queryClient.invalidateQueries({ queryKey: getGetAllBotsStatusQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetBotSlotsStatusQueryKey(botId) });
      },
    },
  });

  const restartMut = useRestartBot({
    mutation: {
      onSuccess: (data) => {
        toast({ title: "Restarting", description: data.message });
        queryClient.invalidateQueries({ queryKey: getGetAllBotsStatusQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetBotSlotsStatusQueryKey(botId) });
      },
    },
  });

  const forceStopMut = useForceStopBot({
    mutation: {
      onSuccess: (data) => {
        toast({ title: "Force Stopped", description: data.message });
        queryClient.invalidateQueries({ queryKey: getGetAllBotsStatusQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetBotSlotsStatusQueryKey(botId) });
      },
    },
  });

  const clearMut = useClearBotConsole({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetBotOutputQueryKey(botId) });
      },
    },
  });

  useEffect(() => {
    if (!socket) return;
    const handleOutput = ({ line }: { line: string }) => {
      setConsoleLines((prev) => [...prev, line]);
      if (isErrorLine(line)) setErrorCount((n) => n + 1);
      const l = line.toLowerCase();
      if (l.includes("exit code") || l.includes("restarting") || l.includes("exited with")) {
        setCrashCount((n) => n + 1);
      }
    };
    const handleCleared = () => {
      setConsoleLines([]);
      setErrorCount(0);
      setCrashCount(0);
    };
    socket.on(`bot:output:${botId}`, handleOutput);
    socket.on(`bot:cleared:${botId}`, handleCleared);
    return () => {
      socket.off(`bot:output:${botId}`, handleOutput);
      socket.off(`bot:cleared:${botId}`, handleCleared);
    };
  }, [socket, botId]);

  useEffect(() => {
    if (outputData?.output) {
      setConsoleLines(outputData.output);
      setErrorCount(outputData.output.filter(isErrorLine).length);
    }
  }, [outputData]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [consoleLines]);

  const status = allStatus?.[botId] as any;
  const isRunning = status?.isRunning || false;
  const slotsRunning: number = status?.slotsRunning ?? 0;
  const anyPending =
    startMut.isPending || stopMut.isPending || restartMut.isPending ||
    forceStopMut.isPending || clearMut.isPending;

  return (
    <Card className="flex flex-col border-border/50 shadow-md">
      {/* Header */}
      <CardHeader className="flex flex-row items-center justify-between pb-4 border-b border-border/50 bg-secondary/20">
        <div className="flex items-center gap-3">
          <TerminalSquare className="w-5 h-5 text-primary" />
          <CardTitle className="text-xl tracking-tight text-white">{title}</CardTitle>
        </div>
        <div className="flex items-center gap-3 text-xs font-mono tracking-wider">
          {errorCount > 0 && (
            <span
              className="flex items-center gap-1 px-2 py-0.5 rounded bg-red-500/10 border border-red-500/30 text-red-400 uppercase"
              title="Error lines in console"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-red-400 inline-block" />
              {errorCount} ERR
            </span>
          )}
          {crashCount > 0 && (
            <span
              className="flex items-center gap-1 px-2 py-0.5 rounded bg-yellow-500/10 border border-yellow-500/30 text-yellow-400 uppercase"
              title="Bot restarts / crashes"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-yellow-400 inline-block" />
              {crashCount} RST
            </span>
          )}
          {isRunning ? (
            <span className="flex items-center gap-1.5 uppercase text-muted-foreground">
              <span className="relative flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-500 opacity-75" />
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-green-500" />
              </span>
              <span className="text-green-500">
                {slotsRunning}/5 Online
              </span>
            </span>
          ) : (
            <span className="flex items-center gap-1.5 uppercase text-muted-foreground">
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-zinc-600" />
              <span className="text-zinc-500">Offline</span>
            </span>
          )}
        </div>
      </CardHeader>

      <CardContent className="flex-1 flex flex-col p-0">
        {/* Actions toolbar */}
        <div className="flex flex-wrap gap-2 px-4 py-3 border-b border-border/30 bg-zinc-950/50">
          <Button
            variant="outline"
            size="sm"
            onClick={() => startMut.mutate({ botId } as any)}
            disabled={isRunning || anyPending}
            className="hover:bg-primary/10 hover:text-primary border-primary/20 font-mono text-xs gap-1"
            data-testid={`button-start-${botId}`}
          >
            <Play className="w-3.5 h-3.5" />
            <Zap className="w-3 h-3 opacity-60" />
            START ALL
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => stopMut.mutate({ botId } as any)}
            disabled={!isRunning || anyPending}
            className="hover:bg-secondary hover:text-foreground border-border/50 font-mono text-xs"
            data-testid={`button-stop-${botId}`}
          >
            <Square className="w-3.5 h-3.5 mr-1.5" /> STOP ALL
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => restartMut.mutate({ botId } as any)}
            disabled={anyPending}
            className="hover:bg-secondary hover:text-foreground border-border/50 font-mono text-xs"
            data-testid={`button-restart-${botId}`}
          >
            <RotateCw className="w-3.5 h-3.5 mr-1.5" /> RESTART
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => forceStopMut.mutate({ botId } as any)}
            disabled={!isRunning || anyPending}
            className="hover:bg-destructive/20 hover:text-destructive border-destructive/20 text-destructive font-mono text-xs ml-auto"
            data-testid={`button-kill-${botId}`}
          >
            <Skull className="w-3.5 h-3.5 mr-1.5" /> KILL ALL
          </Button>
        </div>

        {/* Tab switcher */}
        <div className="flex border-b border-border/50 bg-zinc-950">
          <button
            onClick={() => setActiveTab("console")}
            data-testid={`tab-console-${botId}`}
            className={`flex items-center gap-1.5 px-4 py-2 text-xs font-mono uppercase tracking-wider transition-colors ${
              activeTab === "console"
                ? "text-primary border-b-2 border-primary bg-primary/5"
                : "text-zinc-500 hover:text-zinc-300"
            }`}
          >
            <Terminal className="w-3 h-3" />
            Console
          </button>
          <button
            onClick={() => setActiveTab("accounts")}
            data-testid={`tab-accounts-${botId}`}
            className={`flex items-center gap-1.5 px-4 py-2 text-xs font-mono uppercase tracking-wider transition-colors ${
              activeTab === "accounts"
                ? "text-primary border-b-2 border-primary bg-primary/5"
                : "text-zinc-500 hover:text-zinc-300"
            }`}
          >
            <Users className="w-3 h-3" />
            Accounts
            {slotsRunning > 0 && (
              <span className="ml-1 px-1 py-0.5 text-[9px] rounded bg-green-500/20 text-green-400 border border-green-500/30">
                {slotsRunning}
              </span>
            )}
          </button>
        </div>

        {/* Console tab */}
        {activeTab === "console" && (
          <>
            <div className="relative flex-1 min-h-[380px] max-h-[60vh] bg-zinc-950 p-4 font-mono text-xs sm:text-sm overflow-hidden flex flex-col group">
              <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity z-10">
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-7 w-7 bg-zinc-900/80 hover:bg-zinc-800 text-zinc-400 hover:text-white"
                  onClick={() => clearMut.mutate({ botId } as any)}
                  disabled={anyPending}
                  title="Clear Console"
                  data-testid={`button-clear-${botId}`}
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
              </div>
              <div
                ref={scrollRef}
                className="flex-1 overflow-y-auto overflow-x-auto whitespace-pre font-mono leading-relaxed tracking-tight"
              >
                {consoleLines.length === 0 ? (
                  <span className="text-zinc-600 italic">Waiting for output...</span>
                ) : (
                  consoleLines.map((line, i) => (
                    <div
                      key={i}
                      className={`hover:bg-white/5 px-1 -mx-1 rounded-sm transition-colors ${getLineColor(line)}`}
                    >
                      {line}
                    </div>
                  ))
                )}
              </div>
            </div>
            <div className="flex justify-between items-center px-4 py-2 bg-zinc-950 border-t border-border/30 text-[10px] font-mono text-zinc-500">
              <div data-testid={`text-pid-${botId}`}>
                SLOTS: {slotsRunning}/5 running
              </div>
              <div data-testid={`text-uptime-${botId}`}>
                {status?.uptime || "Stopped"}
              </div>
            </div>
          </>
        )}

        {/* Accounts tab */}
        {activeTab === "accounts" && (
          <div className="flex-1 overflow-y-auto bg-zinc-950 min-h-[380px] max-h-[70vh]">
            <AccountsPanel botId={botId} socket={socket} />
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// ─── TelegramPanel ────────────────────────────────────────────────────────────

function TelegramPanel({ socket }: { socket: Socket | null }) {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [telegramLines, setTelegramLines] = useState<string[]>([]);
  const [maintenance, setMaintenance] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  const { data: status } = useGetTelegramStatus({
    query: { refetchInterval: 3000, queryKey: getGetTelegramStatusQueryKey() },
  });
  const { data: outputData } = useGetTelegramOutput({
    query: { queryKey: getGetTelegramOutputQueryKey() },
  });

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: getGetTelegramStatusQueryKey() });
  };

  const startMut = useStartTelegramBot({ mutation: { onSuccess: invalidate } });
  const stopMut = useStopTelegramBot({ mutation: { onSuccess: invalidate } });
  const restartMut = useRestartTelegramBot({ mutation: { onSuccess: invalidate } });
  const forceMut = useForceStopTelegramBot({ mutation: { onSuccess: invalidate } });
  const clearMut = useClearTelegramConsole({
    mutation: {
      onSuccess: () => {
        setTelegramLines([]);
        queryClient.invalidateQueries({ queryKey: getGetTelegramOutputQueryKey() });
      },
    },
  });
  const enableMaint = useEnableTelegramMaintenance({
    mutation: {
      onSuccess: () => {
        setMaintenance(true);
        toast({ title: "وضع الصيانة مُفعَّل", description: "Maintenance mode enabled." });
        invalidate();
      },
    },
  });
  const disableMaint = useDisableTelegramMaintenance({
    mutation: {
      onSuccess: () => {
        setMaintenance(false);
        toast({ title: "وضع الصيانة أُلغي", description: "Maintenance mode disabled." });
        invalidate();
      },
    },
  });

  useEffect(() => {
    if (outputData?.output) setTelegramLines(outputData.output);
  }, [outputData]);

  useEffect(() => {
    if (status?.maintenanceMode !== undefined) setMaintenance(status.maintenanceMode);
  }, [status?.maintenanceMode]);

  useEffect(() => {
    if (!socket) return;
    const onLine = ({ line }: { line: string }) => {
      setTelegramLines((prev) => {
        const next = [...prev, line];
        return next.length > 500 ? next.slice(-500) : next;
      });
    };
    const onCleared = () => setTelegramLines([]);
    socket.on("telegram:output", onLine);
    socket.on("telegram:cleared", onCleared);
    return () => {
      socket.off("telegram:output", onLine);
      socket.off("telegram:cleared", onCleared);
    };
  }, [socket]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [telegramLines]);

  const isRunning = status?.isRunning ?? false;
  const anyPending =
    startMut.isPending || stopMut.isPending || restartMut.isPending || forceMut.isPending;
  const maintPending = enableMaint.isPending || disableMaint.isPending;

  return (
    <Card className="flex flex-col border border-blue-500/30 bg-card overflow-hidden shadow-lg shadow-blue-950/20">
      {/* Header */}
      <CardHeader className="flex flex-row items-center gap-3 p-4 bg-blue-950/20 border-b border-blue-500/20 flex-shrink-0">
        <div className={`p-1.5 rounded-md ${isRunning ? "bg-blue-500/20" : "bg-zinc-800"}`}>
          <Send className={`w-4 h-4 ${isRunning ? "text-blue-400" : "text-zinc-500"}`} />
        </div>
        <div className="flex-1 min-w-0">
          <CardTitle className="text-sm font-mono tracking-widest text-blue-300 flex items-center gap-2">
            TELEGRAM BOT
            <span className={`ml-1 px-2 py-0.5 text-[10px] rounded-full border font-mono ${
              isRunning
                ? "bg-blue-500/20 text-blue-400 border-blue-500/30"
                : "bg-zinc-800 text-zinc-500 border-zinc-700"
            }`}>
              {isRunning ? "ONLINE" : "OFFLINE"}
            </span>
          </CardTitle>
          <p className="text-[11px] text-zinc-500 font-mono mt-0.5">
            PID: {status?.pid ?? "—"} · {isRunning ? "Running" : "Stopped"}
          </p>
        </div>

        {/* Maintenance toggle */}
        <button
          onClick={() => {
            if (maintenance) disableMaint.mutate();
            else enableMaint.mutate();
          }}
          disabled={maintPending}
          title={maintenance ? "Disable Maintenance Mode" : "Enable Maintenance Mode"}
          className={`flex items-center gap-2 px-3 py-1.5 rounded-md border text-xs font-mono transition-all ${
            maintenance
              ? "bg-yellow-500/15 border-yellow-500/40 text-yellow-400 hover:bg-yellow-500/25"
              : "bg-zinc-800/60 border-zinc-700 text-zinc-400 hover:bg-zinc-700/60 hover:text-zinc-200"
          } disabled:opacity-50 disabled:cursor-not-allowed`}
        >
          {maintenance ? (
            <ShieldCheck className="w-3.5 h-3.5" />
          ) : (
            <ShieldOff className="w-3.5 h-3.5" />
          )}
          <span className="hidden sm:inline">
            {maintenance ? "MAINTENANCE ON" : "MAINTENANCE OFF"}
          </span>
          <div className={`relative w-9 h-5 rounded-full border transition-colors ml-1 ${
            maintenance ? "bg-yellow-500/30 border-yellow-500/50" : "bg-zinc-700 border-zinc-600"
          }`}>
            <div className={`absolute top-0.5 h-4 w-4 rounded-full transition-all shadow-sm ${
              maintenance
                ? "left-4 bg-yellow-400"
                : "left-0.5 bg-zinc-400"
            }`} />
          </div>
        </button>
      </CardHeader>

      <CardContent className="flex flex-col flex-1 p-0 gap-0">
        {/* Controls */}
        <div className="flex flex-wrap items-center gap-2 p-3 bg-secondary/20 border-b border-border/30">
          <Button
            variant="outline"
            size="sm"
            onClick={() => startMut.mutate()}
            disabled={isRunning || anyPending}
            className="hover:bg-blue-500/20 hover:text-blue-400 hover:border-blue-500/30 border-border/50 font-mono text-xs"
          >
            <Play className="w-3.5 h-3.5 mr-1.5" /> START
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => stopMut.mutate()}
            disabled={!isRunning || anyPending}
            className="hover:bg-secondary hover:text-foreground border-border/50 font-mono text-xs"
          >
            <Square className="w-3.5 h-3.5 mr-1.5" /> STOP
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => restartMut.mutate()}
            disabled={anyPending}
            className="hover:bg-secondary hover:text-foreground border-border/50 font-mono text-xs"
          >
            <RotateCw className="w-3.5 h-3.5 mr-1.5" /> RESTART
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => forceMut.mutate()}
            disabled={!isRunning || anyPending}
            className="hover:bg-destructive/20 hover:text-destructive border-destructive/20 text-destructive font-mono text-xs ml-auto"
          >
            <Skull className="w-3.5 h-3.5 mr-1.5" /> KILL
          </Button>
        </div>

        {/* Console */}
        <div className="relative flex-1 min-h-[320px] max-h-[55vh] bg-zinc-950 p-4 font-mono text-xs sm:text-sm overflow-hidden flex flex-col group">
          <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity z-10">
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7 bg-zinc-900/80 hover:bg-zinc-800 text-zinc-400 hover:text-white"
              onClick={() => clearMut.mutate()}
              title="Clear Console"
            >
              <Trash2 className="h-3.5 w-3.5" />
            </Button>
          </div>
          <div
            ref={scrollRef}
            className="flex-1 overflow-y-auto overflow-x-auto whitespace-pre font-mono leading-relaxed tracking-tight"
          >
            {telegramLines.length === 0 ? (
              <span className="text-zinc-600 italic">Waiting for output...</span>
            ) : (
              telegramLines.map((line, i) => (
                <div
                  key={i}
                  className={`hover:bg-white/5 px-1 -mx-1 rounded-sm transition-colors ${getLineColor(line)}`}
                >
                  {line}
                </div>
              ))
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="flex justify-between items-center px-4 py-2 bg-zinc-950 border-t border-border/30 text-[10px] font-mono text-zinc-500">
          <div className="flex items-center gap-1.5">
            {maintenance ? (
              <><Wrench className="w-3 h-3 text-yellow-500" /> <span className="text-yellow-500">MAINTENANCE MODE</span></>
            ) : (
              <><Send className="w-3 h-3" /> TELEGRAM</>
            )}
          </div>
          <div>{isRunning ? "● RUNNING" : "○ STOPPED"}</div>
        </div>
      </CardContent>
    </Card>
  );
}

// ─── Home page ────────────────────────────────────────────────────────────────

export default function Home() {
  const [socket, setSocket] = useState<Socket | null>(null);

  useEffect(() => {
    const newSocket = io({ path: "/api/socket.io" });
    setSocket(newSocket);
    return () => { newSocket.disconnect(); };
  }, []);

  const { data: allStatus } = useGetAllBotsStatus({
    query: { refetchInterval: 3000, queryKey: getGetAllBotsStatusQueryKey() },
  });

  const julhasSlots = (allStatus?.julhas as any)?.slotsRunning ?? 0;
  const blkSlots = (allStatus?.blk as any)?.slotsRunning ?? 0;
  const totalSlots = julhasSlots + blkSlots;

  return (
    <div className="min-h-[100dvh] w-full bg-background text-foreground flex flex-col selection:bg-primary/30">
      <header className="sticky top-0 z-50 w-full border-b border-border/50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80">
        <div className="container px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-primary/10 rounded-md">
              <Activity className="w-5 h-5 text-primary" />
            </div>
            <h1 className="text-lg font-bold tracking-tight text-white flex items-center gap-2">
              FREE FIRE{" "}
              <span className="text-primary font-mono font-normal opacity-80">// NOC</span>
            </h1>
          </div>
          <div className="hidden sm:flex items-center gap-2 text-sm font-mono text-muted-foreground border border-border/50 rounded-md px-3 py-1.5 bg-secondary/30">
            <Server className="w-4 h-4" />
            SLOTS ONLINE:{" "}
            <span className={totalSlots > 0 ? "text-primary" : "text-zinc-500"}>
              {totalSlots}/10
            </span>
          </div>
        </div>
      </header>

      <main className="flex-1 container px-4 py-6 md:py-8 mx-auto space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
          <BotPanel botId="julhas" title="JULHAS TCP BOT" socket={socket} />
          <BotPanel botId="blk" title="BLK ROBOT BOT" socket={socket} />
        </div>
        <TelegramPanel socket={socket} />
      </main>
    </div>
  );
}
